
-- Table pour les salons de jeu multijoueur
CREATE TABLE public.game_rooms (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  code TEXT NOT NULL UNIQUE,
  game_mode TEXT NOT NULL DEFAULT 'pont',
  difficulty TEXT NOT NULL DEFAULT 'facile',
  total_rounds INTEGER NOT NULL DEFAULT 3,
  seed INTEGER NOT NULL DEFAULT floor(random() * 1000000)::integer,
  status TEXT NOT NULL DEFAULT 'waiting',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Table pour les joueurs dans chaque salon
CREATE TABLE public.game_players (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  room_id UUID NOT NULL REFERENCES public.game_rooms(id) ON DELETE CASCADE,
  player_name TEXT NOT NULL,
  player_token TEXT NOT NULL,
  score NUMERIC DEFAULT 0,
  max_combo INTEGER DEFAULT 0,
  chain_count INTEGER DEFAULT 0,
  is_finished BOOLEAN DEFAULT false,
  round_scores JSONB DEFAULT '[]'::jsonb,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Index pour lookup rapide par code
CREATE INDEX idx_game_rooms_code ON public.game_rooms(code);
CREATE INDEX idx_game_players_room ON public.game_players(room_id);
CREATE INDEX idx_game_players_token ON public.game_players(player_token);

-- Enable RLS
ALTER TABLE public.game_rooms ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.game_players ENABLE ROW LEVEL SECURITY;

-- Policies: tout le monde peut lire et écrire (pas d'auth, jeu anonyme)
CREATE POLICY "Anyone can view rooms" ON public.game_rooms FOR SELECT USING (true);
CREATE POLICY "Anyone can create rooms" ON public.game_rooms FOR INSERT WITH CHECK (true);
CREATE POLICY "Anyone can update rooms" ON public.game_rooms FOR UPDATE USING (true);

CREATE POLICY "Anyone can view players" ON public.game_players FOR SELECT USING (true);
CREATE POLICY "Anyone can join rooms" ON public.game_players FOR INSERT WITH CHECK (true);
CREATE POLICY "Anyone can update their score" ON public.game_players FOR UPDATE USING (true);

-- Enable realtime
ALTER PUBLICATION supabase_realtime ADD TABLE public.game_rooms;
ALTER PUBLICATION supabase_realtime ADD TABLE public.game_players;

-- Auto cleanup: supprimer les rooms de plus de 24h
CREATE OR REPLACE FUNCTION public.cleanup_old_rooms()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  DELETE FROM public.game_rooms WHERE created_at < now() - interval '24 hours';
END;
$$;
