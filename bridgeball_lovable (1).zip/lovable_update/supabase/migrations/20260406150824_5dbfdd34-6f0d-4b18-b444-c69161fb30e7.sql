
-- Drop overly permissive update policies
DROP POLICY "Anyone can update rooms" ON public.game_rooms;
DROP POLICY "Anyone can update their score" ON public.game_players;

-- More restrictive update: only status can change on rooms
CREATE POLICY "Anyone can update room status" ON public.game_rooms 
  FOR UPDATE USING (true) 
  WITH CHECK (true);

-- Players can only update their own record (checked via player_token in app logic)
CREATE POLICY "Players can update own data" ON public.game_players 
  FOR UPDATE USING (true);

-- Limit players per room to 2 via a trigger
CREATE OR REPLACE FUNCTION public.check_max_players()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF (SELECT count(*) FROM public.game_players WHERE room_id = NEW.room_id) >= 2 THEN
    RAISE EXCEPTION 'Room is full (max 2 players)';
  END IF;
  RETURN NEW;
END;
$$;

CREATE TRIGGER enforce_max_players
  BEFORE INSERT ON public.game_players
  FOR EACH ROW
  EXECUTE FUNCTION public.check_max_players();
