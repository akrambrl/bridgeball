-- ══ CLASSEMENT MONDIAL ══

CREATE TABLE public.leaderboard (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  player_name TEXT NOT NULL,
  score NUMERIC NOT NULL,
  game_mode TEXT NOT NULL DEFAULT 'pont',   -- 'pont' | 'chaine'
  difficulty TEXT NOT NULL DEFAULT 'facile', -- 'facile' | 'moyen' | 'expert'
  total_rounds INTEGER NOT NULL DEFAULT 3,
  max_combo INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Index pour les requêtes de classement
CREATE INDEX idx_leaderboard_score      ON public.leaderboard(score DESC);
CREATE INDEX idx_leaderboard_mode_diff  ON public.leaderboard(game_mode, difficulty, score DESC);
CREATE INDEX idx_leaderboard_created    ON public.leaderboard(created_at DESC);

-- RLS
ALTER TABLE public.leaderboard ENABLE ROW LEVEL SECURITY;

-- Tout le monde peut lire
CREATE POLICY "Anyone can view leaderboard"
  ON public.leaderboard FOR SELECT USING (true);

-- Personne ne peut insérer directement (on passe par RPC)
CREATE POLICY "No direct insert on leaderboard"
  ON public.leaderboard FOR INSERT WITH CHECK (false);

-- RPC: soumettre un score (validation côté serveur)
CREATE OR REPLACE FUNCTION public.submit_score(
  p_player_name TEXT,
  p_score       NUMERIC,
  p_game_mode   TEXT,
  p_difficulty  TEXT,
  p_total_rounds INTEGER,
  p_max_combo   INTEGER
)
RETURNS UUID
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_id UUID;
BEGIN
  -- Validations basiques
  IF p_player_name IS NULL OR length(trim(p_player_name)) = 0 THEN
    RAISE EXCEPTION 'player_name is required';
  END IF;
  IF length(p_player_name) > 30 THEN
    RAISE EXCEPTION 'player_name too long';
  END IF;
  IF p_game_mode NOT IN ('pont', 'chaine') THEN
    RAISE EXCEPTION 'invalid game_mode';
  END IF;
  IF p_difficulty NOT IN ('facile', 'moyen', 'expert') THEN
    RAISE EXCEPTION 'invalid difficulty';
  END IF;
  -- Pas de score absurde (max théorique ≈ 200)
  IF p_score > 500 OR p_score < -50 THEN
    RAISE EXCEPTION 'score out of bounds';
  END IF;

  INSERT INTO public.leaderboard
    (player_name, score, game_mode, difficulty, total_rounds, max_combo)
  VALUES
    (trim(p_player_name), p_score, p_game_mode, p_difficulty, p_total_rounds, p_max_combo)
  RETURNING id INTO v_id;

  RETURN v_id;
END;
$$;

-- RPC: top 100 pour un mode/difficulté donné
CREATE OR REPLACE FUNCTION public.get_leaderboard(
  p_game_mode  TEXT DEFAULT 'pont',
  p_difficulty TEXT DEFAULT 'facile'
)
RETURNS TABLE(
  rank         BIGINT,
  player_name  TEXT,
  score        NUMERIC,
  max_combo    INTEGER,
  total_rounds INTEGER,
  created_at   TIMESTAMP WITH TIME ZONE
)
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT
    ROW_NUMBER() OVER (ORDER BY lb.score DESC, lb.created_at ASC) AS rank,
    lb.player_name,
    lb.score,
    lb.max_combo,
    lb.total_rounds,
    lb.created_at
  FROM public.leaderboard lb
  WHERE lb.game_mode = p_game_mode
    AND lb.difficulty = p_difficulty
  ORDER BY lb.score DESC, lb.created_at ASC
  LIMIT 100;
$$;
