
-- Tighten INSERT on game_rooms: require status = 'waiting'
DROP POLICY "Anyone can create rooms" ON game_rooms;
CREATE POLICY "Anyone can create rooms"
  ON game_rooms
  FOR INSERT
  WITH CHECK (status = 'waiting');

-- Tighten INSERT on game_players: basic validation
DROP POLICY "Anyone can join rooms" ON game_players;
CREATE POLICY "Anyone can join rooms"
  ON game_players
  FOR INSERT
  WITH CHECK (
    player_name IS NOT NULL 
    AND length(player_name) > 0 
    AND length(player_name) <= 30
    AND player_token IS NOT NULL
  );
