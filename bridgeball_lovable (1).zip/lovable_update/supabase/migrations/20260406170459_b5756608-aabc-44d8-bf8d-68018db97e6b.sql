
-- Drop overly permissive UPDATE policies
DROP POLICY "Players can update own data" ON game_players;
DROP POLICY "Anyone can update room status" ON game_rooms;

-- Create restrictive UPDATE policy on game_players (deny all direct updates)
CREATE POLICY "No direct updates on players"
  ON game_players
  FOR UPDATE
  USING (false);

-- Create restrictive UPDATE policy on game_rooms (deny all direct updates)  
CREATE POLICY "No direct updates on rooms"
  ON game_rooms
  FOR UPDATE
  USING (false);

-- RPC: update player data with token validation
CREATE OR REPLACE FUNCTION public.update_player_data(
  p_player_id uuid,
  p_player_token text,
  p_score numeric,
  p_max_combo integer,
  p_chain_count integer,
  p_round_scores jsonb,
  p_is_finished boolean
)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  UPDATE game_players
  SET score = p_score,
      max_combo = p_max_combo,
      chain_count = p_chain_count,
      round_scores = p_round_scores,
      is_finished = p_is_finished,
      updated_at = now()
  WHERE id = p_player_id
    AND player_token = p_player_token;
  
  RETURN FOUND;
END;
$$;

-- RPC: finish game room (validates both players are done)
CREATE OR REPLACE FUNCTION public.finish_game_room(
  p_room_id uuid,
  p_player_token text
)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Verify caller is a player in this room
  IF NOT EXISTS (
    SELECT 1 FROM game_players
    WHERE room_id = p_room_id AND player_token = p_player_token
  ) THEN
    RETURN false;
  END IF;

  -- Check if all players are finished
  IF (SELECT bool_and(COALESCE(is_finished, false)) FROM game_players WHERE room_id = p_room_id) THEN
    UPDATE game_rooms SET status = 'finished', updated_at = now() WHERE id = p_room_id;
    RETURN true;
  END IF;

  RETURN false;
END;
$$;

-- RPC: start game (when second player joins)
CREATE OR REPLACE FUNCTION public.start_game_room(
  p_room_id uuid,
  p_player_token text
)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Verify caller is a player in this room
  IF NOT EXISTS (
    SELECT 1 FROM game_players
    WHERE room_id = p_room_id AND player_token = p_player_token
  ) THEN
    RETURN false;
  END IF;

  -- Only start if room is in waiting status
  UPDATE game_rooms SET status = 'playing', updated_at = now()
  WHERE id = p_room_id AND status = 'waiting';

  RETURN FOUND;
END;
$$;
