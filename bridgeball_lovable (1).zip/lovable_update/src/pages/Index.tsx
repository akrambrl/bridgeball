import LePont from "@/components/LePont";

const Index = () => <LePont />;

export default Index;
